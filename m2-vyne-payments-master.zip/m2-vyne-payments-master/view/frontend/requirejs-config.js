var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/minicart': {
                'Vyne_Payments/js/view/minicart-mixin': true
            }
        }
    }
};
